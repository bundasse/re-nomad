import { useState, useEffect } from "react";
import Button from "./Button";
import styles from './App.module.css';
function Hello(){
  useEffect(function() {
  console.log("Created");
  return () => console.log("Destroyed");
},[])
  return <h1>Hello</h1>;
}

function App() {
  const [counter, setCounter] = useState(0);
  const [keyword, setKeyword] = useState("");
  const [show, setShow] = useState(false);
  const onClick = () => {setCounter((prev) => prev+1 )}
  const onClick2 = () => {setShow((prev) => !prev )}
  const onChange = (event) => {setKeyword(event.target.value)}
  const searchFor = () => {console.log("Search for", keyword);}
  // 그냥 쓰면 버튼을 클릭하거나 할때도 계속 실행된다. 만약 keyword가 바뀔때만 쓰고싶다면?
  const iRunOnlyOnce = ()=>{
    console.log("call an API");
  }
  useEffect(iRunOnlyOnce,[]);
  // 앞에 넣은 친구는 처음 컴포넌트가 생성될 때에만 실행된다. refresh할땐 실행되지 않음!
  useEffect(searchFor,[keyword]);
  // keyword 가 바뀔 때에만 searchFor를 작동 시킬 것!
  return (
    <div className="App">
      <input type="text" placeholder="Search here..." onChange={onChange} value={keyword} />
      {keyword}
      <h1 className={styles.title}>{counter}</h1>
      <button onClick={onClick}> 버튼 </button>
      <button onClick={onClick2}> {show? "hide" : "show"} </button>
      <Button text={"Continue"} />
      {show? <Hello/> : null}
    </div>
  );
}

export default App;

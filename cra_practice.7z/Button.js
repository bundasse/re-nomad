import PropTypes from 'prop-types';
import styles from './Button.module.css';

function Button({text}) {
  return (
    <button className={styles.btn}>{text}</button>
    // 스타일의 모듈화가 가능하다. scoped랑 비슷하네...
  )
}

Button.propTypes ={
  text: PropTypes.string.isRequired,
}

export default Button;